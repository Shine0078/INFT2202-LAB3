// namespace core
let core;
// Name : Samuel Abraham, Sandeep Kuamr
// Student id : 100870571 , 100844683
// Date : 14-03-2024